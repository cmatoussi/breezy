A Pen created at CodePen.io. You can find this one at https://codepen.io/gin2000/pen/ZwxQoV.

 A basic mood selector with pictures